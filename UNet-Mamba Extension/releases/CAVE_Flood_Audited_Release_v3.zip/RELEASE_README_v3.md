# CAVE-Flood v1 Release Bundle (Version 3 — Final Audited Release)

## Overview
This package contains the complete, independently verified deliverables, authoritative metrics, explainable AI diagnostics, source code, and checkpoints for CAVE-Flood v1: Confidence-Aware Vision-Language-Guided Residual Refinement for Flood Inundation Segmentation on PlanetScope satellite imagery.

This Version 3 release is the product of an exhaustive independent computer-vision and scientific reproducibility audit. It includes:
1. Forensic provenance documentation resolving the test confusion matrix discrepancy against raw physical labels (`reports/CONFUSION_MATRIX_PROVENANCE.md`).
2. Complete authoritative metric tables across validation and held-out test splits (`reports/CORRECTED_METRICS.md`).
3. Mathematical verification and bug fix for LayerCAM with zero parameter drift (`reports/LAYERCAM_VERIFICATION.md`).
4. Spatial diagnostics, color map verification, and scene-level confusion matrices (`reports/XAI_VERIFICATION.md`).
5. Critical scientific limitations including RemoteCLIP guidance marginality, precision penalties, and mountain degradation (`reports/SCIENTIFIC_LIMITATIONS.md`).
6. Master independent audit synthesis and final verdict (`reports/FINAL_INDEPENDENT_AUDIT.md`).
7. Complete project changelog (`reports/CHANGELOG.md`).
8. Master automated audit test suite (`src/run_all_audits.py`).

## Checkpoint Cryptographic Integrity (SHA-256)
- Base UNet-Mamba (`checkpoints/best_model.pth`, 171.8 MB, preserved in workspace):
  SHA256: `58674C84E97E16C7AB86F2E218BA8738C7AAF69A8C6FD8C384DE00BEEC9EB76D`
- CASR E1 Adapter (`checkpoints/best_e1_model.pth`, 54.4 KB):
  SHA256: `84A02D1F1FE8371BF799EDB0DDCE28F69D20DD90B3DA503C06EAC87F521226E9`
- CASR E2 Adapter (`checkpoints/best_e2_model.pth`, 54.4 KB):
  SHA256: `19347F5F64385C46F16C27B345A7F143E56B51F23C1FE7E887906B6E7C19D2D9`

## Verification Command
To independently verify all checkpoints, ground-truth label counts, metric formulas, and LayerCAM/XAI diagnostics:
```powershell
python src/run_all_audits.py
```
